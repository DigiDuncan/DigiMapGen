# DigiMapGen
 It generates maps. Pretty self-explanatory.

 Oh, except that it uses Turtle Graphics. 🐢


## To use:
* Start the program using `run.bat`.
* Select one of the generators using the prompts.
* **OPTIONAL**: Edit conf.py to change settings.
